'''
Author: Sumayyah Khalid
ID: 169022335
Email: khal2335@mylaurier.ca
__updated__:Jan. 11, 2024
'''

from Food_utilities import get_food

k = get_food()

print(k)