'''
Author: Sumayyah Khalid
ID: 169022335
Email: khal2335@mylaurier.ca
__updated__:Jan. 11, 2024
'''

from Food import Food

p = Food("Ravioli", 7 , False, 246)

print(p.__str__())